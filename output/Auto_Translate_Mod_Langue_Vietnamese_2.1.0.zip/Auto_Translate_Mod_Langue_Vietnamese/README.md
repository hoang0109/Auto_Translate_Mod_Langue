# Auto_Translate_Mod_Langue_Vietnamese v2.1.0

## Gói Dịch Tiếng Việt Factorio Mods

**Phát triển bởi Hoang0109**

### ✨ Tính năng:
- 50+ mod Factorio được Việt hóa
- Tương thích Factorio 2.0+
- Chất lượng dịch thuật cao
- Cập nhật thường xuyên

### 📦 Mod được hỗ trợ:
aai-industry, alien-biomes, Babelfish, BigBags, RateCalculator, 
jetpack, even-distribution, far-reach, squeak-through-2,
PersonalMagnet, BeltSpeedMultiplier, Turret-Shields và nhiều mod khác...

### 🚀 Cài đặt:
1. Tải và cài mod vào Factorio
2. Enable trong menu Mods  
3. Khởi động lại game
4. Tất cả mod hỗ trợ sẽ hiển thị tiếng Việt

### 📞 Liên hệ:
- GitHub: https://github.com/hoang0109/Auto_Translate_Mod_Langue
- Email: hoang0109.dev@gmail.com

*Cảm ơn cộng đồng Factorio Việt Nam!*
