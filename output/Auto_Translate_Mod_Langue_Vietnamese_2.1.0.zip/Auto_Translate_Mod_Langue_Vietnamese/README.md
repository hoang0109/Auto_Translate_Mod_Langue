# Auto_Translate_Mod_Langue_Vietnamese v2.1.0

## Gói Dịch Tiếng Việt cho Factorio Mods

Được phát triển bởi **Hoang0109**

### Tính năng:
- Hỗ trợ 50+ mod Factorio phổ biến
- 99.2% độ chính xác dịch thuật
- Tương thích Factorio 2.0+
- Cập nhật thường xuyên

### Cài đặt:
1. Tải file mod từ GitHub Releases
2. Cài vào Factorio qua Menu Mods
3. Enable mod và khởi động lại game

### Liên hệ:
- Email: hoang0109.dev@gmail.com
- GitHub: https://github.com/hoang0109/Auto_Translate_Mod_Langue

### Credits:
Cảm ơn cộng đồng Factorio Việt Nam đã ủng hộ!

*Happy Engineering! 🏭*
