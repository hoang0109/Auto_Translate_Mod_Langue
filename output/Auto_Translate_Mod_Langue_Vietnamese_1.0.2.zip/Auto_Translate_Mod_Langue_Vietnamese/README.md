# Auto_Translate_Mod_Langue_Vietnamese v1.0.2

## Gói Dịch Tiếng Việt Factorio Mods

**Phát triển bởi Hoang0109**

### ✨ Tính năng v1.0.2:
- 45+ mod Factorio được Việt hóa
- 8,500+ chuỗi văn bản đã dịch
- Tương thích Factorio 2.0+
- Chất lượng dịch thuật ổn định

### 🆕 Mod mới trong v1.0.2:
PersonalMagnet, BeltSpeedMultiplier, MachineSpeedMultiplier, 
Turret-Shields, inventory-repair, chest-auto-sort và nhiều mod khác...

### 🚀 Cài đặt:
1. Tải file .zip
2. Cài vào Factorio via Menu Mods
3. Enable mod và restart game
4. Tất cả mod hỗ trợ hiển thị tiếng Việt

### 📞 Hỗ trợ:
- GitHub: https://github.com/hoang0109/Auto_Translate_Mod_Langue
- Email: hoang0109.dev@gmail.com

*Cảm ơn cộng đồng Factorio Việt Nam!*
