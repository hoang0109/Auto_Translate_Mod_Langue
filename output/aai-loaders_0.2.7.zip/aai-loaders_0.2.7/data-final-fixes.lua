if mods["pypostprocessing"] then
  require("prototypes/loader-sets/pyanodons")
end
