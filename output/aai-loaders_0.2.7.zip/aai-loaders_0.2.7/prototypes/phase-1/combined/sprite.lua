data:extend({
  {
    type = "sprite",
    name = "fluid-icon-red",
    filename = "__core__/graphics/icons/alerts/fluid-icon-red.png",
    width = 64,
    height = 64
  }
})
