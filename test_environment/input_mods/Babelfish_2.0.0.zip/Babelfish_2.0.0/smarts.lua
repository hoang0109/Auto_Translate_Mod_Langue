local Lib = require('lib')
local Gui = require('gui')
local Smarts = {}

Smarts.exclude = {
    -- "dummy-steel-axe",
    -- "disabled-artillery-wagon-cannon"
}

Smarts.on_translations_complete_event = script.generate_event_name()

local function make_queue()
    local queue = {}

    local types = {}
    if settings.global["babelfish-translate-entity"].value then table.insert(types, 'entity') end
    if settings.global["babelfish-translate-fluid"].value then table.insert(types, 'fluid') end
    if settings.global["babelfish-translate-item"].value then table.insert(types, 'item') end
    if settings.global["babelfish-translate-recipe"].value then table.insert(types, 'recipe') end
    if settings.global["babelfish-translate-technology"].value then table.insert(types, 'technology') end
    if settings.global["babelfish-translate-tile"].value then table.insert(types, 'tile') end
    if settings.global["babelfish-translate-virtual_signal"].value then table.insert(types, 'virtual_signal') end

    for _, typ in pairs(types) do
        for _, prototype in pairs(prototypes[typ]) do
            if Lib.contains(Smarts.exclude, prototype.name) then
                -- skipping
            else
                local key = typ .. "@" .. prototype.name
                queue[key] = { type = typ, prototype = prototype }
            end
        end
    end
    storage.max_translations = table_size(queue)
    return queue
end

local function get_job(player_name)
    for i, j in pairs(storage.queue) do
        if not j.translator then
            j.translator = player_name
            return i, j
        end
        -- if j.translator == player_name then
        --     return i, j
        -- end
    end
    return nil, nil
end

---@param player LuaPlayer
local function give_translation_work(player)
    if storage.translators[player.index].busy then return end
    if storage.translators[player.index].language ~= settings.global["babelfish-language"].value then
        storage.translators[player.index].busy = true
        return
    end

    local total = table_size(storage.queue)
    local pct = (storage.max_translations - total) / storage.max_translations
    Gui.show_progress(player, pct)

    storage.translators[player.index].tasks = storage.translators[player.index].tasks or 0
    storage.translators[player.index].jobs = storage.translators[player.index].jobs or {}
    if table_size(storage.translators[player.index].jobs) > 0 then
        return
    end

    local actions = {}
    local jobs = {}
    while table_size(storage.translators[player.index].jobs) <= settings.global["babelfish-batch-size"].value do
        local index, job
        index, job = get_job(player.index)
        if index and job then
            storage.translators[player.index].tasks = storage.translators[player.index].tasks + 1
            storage.translators[player.index].jobs[index] = true
            table.insert(jobs, index)
            table.insert(actions, job.prototype.localised_name)
        else
            break
        end
    end

    if table_size(actions) > 0 then
        local rv = player.request_translations(actions)
        if rv then
            for idx, identifier in pairs(rv) do
                local index = jobs[idx]
                storage.identifiers[identifier] = index
            end
            storage.translators[player.index].busy = true
            storage.translators[player.index].tick = game.tick
        end
        return
    end

    if #storage.queue > 0 then
        log("Queue was not empty")
        for k, v in pairs(storage.queue) do
            log(k)
        end
    end

    storage.translating = false
    if player.gui.left["Babelfish_progress"] then player.gui.left["Babelfish_progress"].destroy() end
    player.print("Babelfish .. Translations Complete")
    script.raise_event(Smarts.on_translations_complete_event, {})
end

---@param evt EventData.on_string_translated
function Smarts.on_string_translated(evt)
    local player = game.get_player(evt.player_index)
    if not player then return end

    if evt.translated then
        if type(evt.localised_string) == "table" and Lib.table_compare(evt.localised_string, { "locale-identifier" }) then
            storage.translators[player.index].language = evt.result
            give_translation_work(player)
            return
        end
    end

    if storage.identifiers[evt.id] then
        local index = storage.identifiers[evt.id]
        local name = storage.queue[index].prototype.name
        local typ = storage.queue[index].type
        if typ and name then
            storage.translations[typ] = storage.translations[typ] or {}
            if evt.translated then
                storage.translations[typ][name] = evt.result
            else
                storage.translations[typ][name] = name
            end
            storage.queue[index] = nil
            storage.translators[player.index].jobs[index] = nil
            storage.translators[player.index].busy = false
        end
        storage.identifiers[evt.id] = nil
        give_translation_work(player)
    end
end

function Smarts.reset_translations()
    storage.translating = true
    storage.translations = {}
    storage.queue = make_queue()
    storage.jobs = {}
    for _, player in pairs(game.connected_players) do
        storage.translators[player.index] = { entity = player, busy = false, tasks = 0 }
        player.request_translation({ "locale-identifier" })
    end
end

function Smarts.init_globals()
    storage.max_translations = 0
    storage.translators = {}
    storage.translations = storage.translations or {}
    storage.queue = storage.queue or make_queue()
    storage.jobs = storage.jobs or {}
    storage.identifiers = storage.identifiers or {}
    storage.translating = storage.translating or true
end

function Smarts.on_init()
    Smarts.init_globals()
end

function Smarts.on_load()
end

---@param evt ConfigurationChangedData
function Smarts.on_configuration_changed(evt)
    Smarts.init_globals()
    Smarts.reset_translations()
end

---@param evt on_player_created|on_player_joined_game
function Smarts.on_player_connected(evt)
    local player = game.get_player(evt.player_index)
    if player and player.connected then
        storage.translators[player.index] = { entity = player, busy = false, tick = game.tick, tasks = 0 }
        player.request_translation({ "locale-identifier" })
    end
end

---@param evt on_player_left_game
function Smarts.on_player_left(evt)
    local player = game.get_player(evt.player_index)
    if player then
        if storage.translators[player.index] then
            if storage.translators[player.index].jobs then
                for job_idx, _ in pairs(storage.translators[player.index].jobs) do
                    if storage.queue[job_idx] then
                        storage.queue[job_idx].translation = nil
                    end
                end
            end
        end
        storage.translators[player.index] = nil
    end
end

---@param evt EventData.on_runtime_mod_setting_changed
function Smarts.on_runtime_mod_setting_changed(evt)
    if evt.setting_type == "runtime-global" and Lib.starts_with(evt.setting, "babelfish-translate") then
        Smarts.reset_translations()
    end
    if evt.setting_type == "runtime-global" and evt.setting == "babelfish-language" then
        local flag = false
        local lang = "en"
        for _, player_data in pairs(storage.translators) do
            lang = player_data.language
            if player_data and player_data.language and settings.global["babelfish-language"].value == player_data.language then
                flag = true
            end
        end
        if not flag then
            game.print("No one on the server is using the language .. " .. settings.global["babelfish-language"].value)
            settings.global["babelfish-language"] = { value = lang }
        else
            Smarts.reset_translations()
        end
    end
end

---@param evt EventData.on_tick
function Smarts.on_nth_tick(evt)
    if not storage.translating then return end

    local tick = evt.tick
    for _, player in pairs(game.connected_players) do
        local flag = false
        if storage.translators[player.index] then
            local translator_tick = storage.translators[player.index].tick or 0
            if translator_tick + 300 < tick then
                flag = true
            end
        else
            flag = true
        end
        if flag then
            storage.translators[player.index] = { entity = player, busy = false, tick = game.tick }
            player.request_translation({ "locale-identifier" })
        end
    end
end

return Smarts
