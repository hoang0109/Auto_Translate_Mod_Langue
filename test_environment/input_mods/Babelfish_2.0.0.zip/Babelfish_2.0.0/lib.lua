local lib = {} ---@class HelperLibrary

---Check strings ends with phrase
---@param str string
---@param ending string
---@return boolean
lib.ends_with = function(str, ending)
    return ending == "" or str:sub(-(#ending)) == ending
end

---Check strings starts with phrase
---@param str string
---@param start string
---@return boolean
lib.starts_with = function(str, start)
    return str:sub(1, #start) == start
end

---Split strings
---@param s string
---@param regex string|nil
---@return table
lib.splitString = function(s, regex)
    local chunks = {}
    local count = 0
    if regex == nil then
        regex = "%S+"
    end

    for substring in s:gmatch(regex) do
        count = count + 1
        chunks[count] = substring
    end
    return chunks
end

---Checks a list for a member of a list
---@param table table
---@param element string
---@return boolean
function lib.contains(table, element)
    for _, value in pairs(table) do
        if value == element then
            return true
        end
    end
    return false
end

function lib.table_compare( tbl1, tbl2 )
    if tbl1 == tbl2 then return true end
    for k, v in pairs( tbl1 ) do
        if  type(v) == "table" and type(tbl2[k]) == "table" then
            if not table.compare( v, tbl2[k] )  then return false end
        else
            if ( v ~= tbl2[k] ) then return false end
        end
    end
    for k, v in pairs( tbl2 ) do
        if tbl1[k] == nil then return false end
    end
    return true
  end

return lib
