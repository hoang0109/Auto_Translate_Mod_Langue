data:extend({
  {
    type = "double-setting",
    name = "BeltSpeedMultiplier-speed-factor",
    setting_type = "startup",
    default_value = 1.0
  }
})
